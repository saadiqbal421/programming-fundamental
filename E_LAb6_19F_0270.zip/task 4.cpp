// ConsoleApplication7.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
using namespace std;
int main()
{
	int age1, age2,pocket1,pocket2;
	cout << "enter age of first child\n";
	cin >> age1;
	cout << "enter age of first child\n";
	cin >> age2;

	pocket1 = age1 * 75;
	pocket2 = age2 * 75;

	cout << "pocket money of first child is";
	cout << pocket1;

	cout << "\npocket money of first child is";
	cout << pocket2;

	return 0;
}

