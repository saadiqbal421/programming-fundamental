// ConsoleApplication9.cpp : Defines the entry point for the console application.
//


#include "stdafx.h"
#include<iostream>
using namespace std;
int main()
{
	int lenght, rate, mowingrate;
	cout << "Input the lenght of the lawn";
	cin >> lenght;
	cout << "Input the rate of lawn";
	cin >> rate;
	mowingrate = (lenght * lenght) * rate;
	cout << "The mowing rate of lawn is ";
	cout << mowingrate;

	return 0;
}
