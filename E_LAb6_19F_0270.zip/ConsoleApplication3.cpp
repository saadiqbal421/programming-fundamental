// ConsoleApplication3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;

int main()
{
	float num1, num2;

	float sum = 0;
	cout << "Enter first number :";
	cin >> num1;
	cout << "Enter Second number :";
	cin >> num2;

	sum = num1 + num2;
	cout << sum;
	cout << " is sum of two numbers\n";
	

	return 0;
}

