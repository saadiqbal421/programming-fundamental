#include <iostream>
#include <string>
using namespace std;
int main()
{
	string n1 = "Problem";
	string n2 = "Solving";
	cout << n1 + n2 << endl;
	string num_a = "8";
	string num_b = "5";
	cout << num_a << num_b;
	system("pause");
	return 0;

}
