#include<iostream>
#include<string>
using namespace std;
const int SECRET = 11;
const double RATE = 12.5;


int main()
{
	int num1, num2, newnum;
	string name;
	double hoursworked=0, wages=0;
	

	cout << "The value of num1 :";
	cin >> num1;
	cout << "The value of num2 :";
	cin >> num2;

	newnum = (2 * num1) + num2;
	cout << newnum<<"is the value of new number"<<endl;

	newnum += SECRET;
	cout << "The value of newnum is " << newnum<<endl;

	cout << "Enter the last name of the person :";
	cin >> name;

	cout << "Enter a decimal number between 0 and 70 :";
	cin >> hoursworked;
	
	wages = RATE*hoursworked;
	cout << "The wages are " << wages<<endl;

	cout << "name :"<<name<<endl;
	cout << "Pay rate " << RATE<<endl;
	cout << "Hours worked" << hoursworked<<endl;
	cout << "Salary" << wages<<endl;
	
	system("pause");
	return 0;
}