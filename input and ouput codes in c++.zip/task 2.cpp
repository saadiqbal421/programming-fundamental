#include <iostream>
using namespace std;
int main()
{
	double a,b,c,d,e;
	int n1,n2,n3,n4,n5, sum, avrg;
	cout << "Enter first number";
	cin >> a;
	cout << "Enter second number";
	cin >> b;
	cout << "Enter third number";
	cin >> c;
	cout << "Enter fourth number";
	cin >> d;
	cout << "Enter fifth number";
	cin >> e;

	n1 = static_cast <int> (a);
	n2 = static_cast <int> (b);
	n3 = static_cast <int> (c);
	n4 = static_cast <int> (d);
	n5 = static_cast <int> (e);

	cout << "Five numbers are\n";
	cout << n1 << endl << n2 << endl << n3 << endl << n4 << endl << n5 << endl;



	sum = n1+n2+n3+n4+n5;
	cout << "Sum of five  numbers is\t";
	cout << sum << endl;
	avrg = sum / 5;

	cout << "The average of the numbers is\t";
	cout << avrg << endl;

	system("pause");
	return 0;

}
